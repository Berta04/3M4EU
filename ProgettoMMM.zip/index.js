const main = require("./Server-Side/main.js")

main.setup();